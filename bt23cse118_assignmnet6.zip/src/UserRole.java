public enum UserRole {
    LIBRARIAN,
    STUDENT
}
